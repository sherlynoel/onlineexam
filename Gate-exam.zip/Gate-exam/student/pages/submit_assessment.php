<?php
if(isset($_POST))
{
error_reporting(0);
$total_questions = $_POST['tq'];
$starting_mark = 1;
$mytotal_marks = 0;
$exam_id = $_POST['eid'];
$record = $_POST['ri'];
$t_mark = $_POST['ttm'];
$e_mark = $_POST['eem'];
$t_question = $_POST['tom'];
$pre = $_POST['pre'];
$passm = 0;
$failm = 0;
$cnt = 0;
while ($starting_mark <= $total_questions) {
    if (strtoupper(base64_decode($_POST['ran'.$starting_mark.''])) == strtoupper($_POST['an'.$starting_mark.''])) {
        $mytotal_marks = $mytotal_marks + $e_mark;
        $passm = $passm + 1;
        $cnt = $cnt + 1;
    }else{
        #$mytotal_marks = $mytotal_marks - 1;
        $failm = $failm + 1;
        $cnt = $cnt + 1;
    }
    $starting_mark++;
}

#$percent_score = $passm-($failm * 0.25);
if($pre == 0){$pre = 100;}
$total_marks = 0;
$total_marks = ($total_questions*$e_mark);
$pret = floor(($mytotal_marks/$total_marks) * $pre);
$passmark = $_POST['pm'];

if ($pret >= $passmark) {
    $status = "PASS";
}else{
    $status = "FAIL";
}

session_start();
$_SESSION['record_id'] = $record;
include '../../database/config.php';
$sql = "UPDATE tbl_assessment_records SET score='$pret', status='$status', c_ans='$passm', f_ans='$failm', total_question='$t_question' WHERE record_id='$record'";

if ($conn->query($sql) === TRUE) {
    
    
    header("location:../assessment-info.php");
} else {
    header("location:../assessment-info.php");
}

$conn->close();

}
?>
